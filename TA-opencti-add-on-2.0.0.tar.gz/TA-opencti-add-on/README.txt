This is an add-on powered by the Splunk Add-on Builder.

# Binary File Declaration

bin/ta_opencti_add_on/aob_py3/yaml/_yaml.cpython-37m-x86_64-linux-gnu.so: This binary file is provided along with Splunk's Add-on Builder module.
bin/ta_opencti_add_on/aob_py3/markupsafe/_speedups.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
bin/ta_opencti_add_on/aob_py3/simplejson/_speedups.cp37-win_amd64.pyd: this file does not require any source code